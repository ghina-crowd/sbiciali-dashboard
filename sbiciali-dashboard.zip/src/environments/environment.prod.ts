export const environment = {
    production: true,
    hmr       : false,
    baseUrl: 'http://93.186.194.133:5001',


};
