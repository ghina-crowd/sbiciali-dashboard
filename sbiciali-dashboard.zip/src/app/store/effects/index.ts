import { RouterEffects } from './router.effect';

export const effects: any[] = [RouterEffects];

export * from './router.effect';
