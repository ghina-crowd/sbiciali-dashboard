import { Component } from '@angular/core';

@Component({
    selector   : 'typography',
    templateUrl: './typography.component.html',
    styleUrls  : ['./typography.component.scss']
})
export class TypographyComponent
{
    /**
     * Constructor
     */
    constructor()
    {
    }
}
