import { Component } from '@angular/core';

@Component({
    selector   : 'typography-headings',
    templateUrl: './headings.component.html',
    styleUrls  : ['./headings.component.scss']
})
export class TypographyHeadingsComponent
{
    /**
     * Constructor
     */
    constructor()
    {

    }
}
