import { Component } from '@angular/core';

@Component({
    selector   : 'typography-message-boxes',
    templateUrl: './message-boxes.component.html',
    styleUrls  : ['./message-boxes.component.scss']
})
export class TypographyMessageBoxesComponent
{
    /**
     * Constructor
     */
    constructor()
    {

    }
}
