import { Component } from '@angular/core';

@Component({
    selector   : 'typography-blockquotes-lists',
    templateUrl: './blockquotes-lists.component.html',
    styleUrls  : ['./blockquotes-lists.component.scss']
})
export class TypographyBlockquotesListsComponent
{
    /**
     * Constructor
     */
    constructor()
    {

    }
}
