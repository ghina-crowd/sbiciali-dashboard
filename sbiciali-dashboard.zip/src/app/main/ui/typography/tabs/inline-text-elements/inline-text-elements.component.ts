import { Component } from '@angular/core';

@Component({
    selector   : 'typography-inline-text-elements',
    templateUrl: './inline-text-elements.component.html',
    styleUrls  : ['./inline-text-elements.component.scss']
})
export class TypographyInlineTextElementsComponent
{
    /**
     * Constructor
     */
    constructor()
    {

    }
}
