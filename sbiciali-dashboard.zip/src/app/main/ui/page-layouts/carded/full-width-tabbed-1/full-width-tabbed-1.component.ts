import { Component } from '@angular/core';

@Component({
    selector   : 'carded-fullwidth-tabbed-1',
    templateUrl: './full-width-tabbed-1.component.html',
    styleUrls  : ['./full-width-tabbed-1.component.scss']
})
export class CardedFullWidthTabbed1Component
{
    /**
     * Constructor
     */
    constructor()
    {
    }
}
