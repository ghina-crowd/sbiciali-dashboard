import { Component } from '@angular/core';

@Component({
    selector   : 'carded-fullwidth-tabbed-2',
    templateUrl: './full-width-tabbed-2.component.html',
    styleUrls  : ['./full-width-tabbed-2.component.scss']
})
export class CardedFullWidthTabbed2Component
{
    /**
     * Constructor
     */
    constructor()
    {
    }
}
