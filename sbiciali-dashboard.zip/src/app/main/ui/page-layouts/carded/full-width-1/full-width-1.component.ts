import { Component } from '@angular/core';

@Component({
    selector   : 'carded-fullwidth-1',
    templateUrl: './full-width-1.component.html',
    styleUrls  : ['./full-width-1.component.scss']
})
export class CardedFullWidth1Component
{
    /**
     * Constructor
     */
    constructor()
    {
    }
}
