import { Component } from '@angular/core';

@Component({
    selector   : 'carded-fullwidth-2',
    templateUrl: './full-width-2.component.html',
    styleUrls  : ['./full-width-2.component.scss']
})
export class CardedFullWidth2Component
{
    /**
     * Constructor
     */
    constructor()
    {
    }
}
