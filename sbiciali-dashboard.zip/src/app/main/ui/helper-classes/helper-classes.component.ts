import { Component } from '@angular/core';

@Component({
    selector   : 'helper-classes',
    templateUrl: './helper-classes.component.html',
    styleUrls  : ['./helper-classes.component.scss']
})
export class HelperClassesComponent
{
    /**
     * Constructor
     */
    constructor()
    {
    }

}
