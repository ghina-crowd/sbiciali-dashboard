export class Filter{
    page: number;
    category_id: number;
    size = 12;
    active: number;
    id: string;
    isExplore: boolean;

}

export class UploadModel {
    image: string;
}