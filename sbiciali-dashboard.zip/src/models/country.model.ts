export interface CountryModel {
    active: number;
    title_en: string;
    title_ar: string;
    _id: string;
    image: string;
}