export interface Category {
    _id: string;
    title_en: string;
    title_ar: string;
    icon: string;
    active: number;
}

