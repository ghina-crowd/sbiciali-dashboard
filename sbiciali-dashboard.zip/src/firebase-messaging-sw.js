// importScripts('https://www.gstatic.com/firebasejs/7.6.0/firebase-app.js');
// importScripts('https://www.gstatic.com/firebasejs/7.6.0/firebase-messaging.js');
// firebase.initializeApp({
//     apiKey: "AIzaSyAVMIjpZdOi5cdKCng-OG5caFEu8ilDjBc",
//     authDomain: "alkbetna.firebaseapp.com",
//     databaseURL: "https://alkbetna.firebaseio.com",
//     projectId: "alkbetna",
//     storageBucket: "alkbetna.appspot.com",
//     messagingSenderId: "354152514713",
//     appId: "1:354152514713:web:cd6032b7fa4dfb17c32408",
//     measurementId: "G-8CFZQWBXYN"
// });
// firebase.messaging();
